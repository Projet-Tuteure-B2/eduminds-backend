package com.eduminds.backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.core.env.Environment;

/**
 * Point d'entrée de l'application Synapz.
 *
 * Note : le package racine reste `com.eduminds.backend` pour ne pas casser
 * les imports. Seul le nom utilisateur visible (UI, logs) est "Synapz".
 */
@SpringBootApplication
public class BackendApplication {

    public static void main(String[] args) {
        ConfigurableApplicationContext ctx = SpringApplication.run(BackendApplication.class, args);

        Environment env = ctx.getEnvironment();
        String port = env.getProperty("server.port", "8082");
        String dbUrl = env.getProperty("spring.datasource.url", "?");
        String hasKey = (env.getProperty("synapz.claude.api-key", "").isEmpty())
                ? "absente (mode dev)"
                : "présente";

        System.out.println();
        System.out.println("══════════════════════════════════════════════════════════════");
        System.out.println("  🧠  SYNAPZ · Backend démarré");
        System.out.println("──────────────────────────────────────────────────────────────");
        System.out.println("  📍  http://localhost:" + port);
        System.out.println("  💾  " + dbUrl);
        System.out.println("  🤖  Clé Claude : " + hasKey);
        System.out.println("══════════════════════════════════════════════════════════════");
        System.out.println();
    }
}
